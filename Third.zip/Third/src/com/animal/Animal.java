package com.animal;

abstract public class Animal {
	 abstract void eat();
     abstract void sleep(); 

}
