package com.animal;

public class Bird extends Animal{

	   void eat() {  
           System.out.println("Bird is eating");  
     }  
   
      void sleep() {  
           System.out.println("Bird is sleeping");  
      }  
     void fly() {  
         System.out.println("Bird is flying");  
      }  
 } 