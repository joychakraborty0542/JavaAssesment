package com.animal;

public class WildAnimal extends Animal {  
    
    void eat() {  
          System.out.println("WildAnimal  is eating");  
    }  
  
     void sleep() {  
          System.out.println("WildAnimal  is sleeping");  
     }  
    void kill() {  
        System.out.println("WildAnimal is killing");  
     }  
} 
