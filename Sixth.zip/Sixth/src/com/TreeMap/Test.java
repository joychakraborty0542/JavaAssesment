package com.TreeMap;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {



 TreeMap1 mapClass=new TreeMap1();
 ArrayList<String> indiaDistrict = new ArrayList<>();


    indiaDistrict.add("Kolkata");
    indiaDistrict.add("Medinpur");
    indiaDistrict.add("Balasore");
    indiaDistrict.add("Bhubaneswar");
    indiaDistrict.add("Hyderbad");

    ArrayList<String> chinaDist = new ArrayList<>();

    chinaDist.add("Bejing");
    chinaDist.add("Honkong");


    ArrayList<String> banglaDist = new ArrayList<>();

    banglaDist.add("Dhaka");
    banglaDist.add("dhakass");

    mapClass.ListingCountry("India", indiaDistrict);
    mapClass.ListingCountry("China", chinaDist);
    mapClass.ListingCountry("Bangladesh", banglaDist);
    
    

  //  System.out.println(mapClass.getCountry("China"));
    //mapClass.listCountryBefore("Bangladesh");
    mapClass.listCountryBefore("China");
    mapClass.listCountryAfter("China");
    


	}

}
