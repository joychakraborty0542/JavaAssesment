package com.TreeMap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMap1 {

	String CountryNAme;

	TreeMap<String, ArrayList<String>> map = new TreeMap<>();

	public ArrayList<String> getCountry(String CountryName) {
		if (map.containsKey(CountryName)) {

			ArrayList<String> a = map.get(CountryName);
			return a;
		} else {
			// System.out.println(map);
			return null;

		}

	}

	public void ListingCountry(String country, ArrayList<String> district) {
		map.put(country, district);
		// System.out.println(map);
	}

	
	

	public void listCountryBefore(String Country) {
		Set<String> set1 = map.keySet();

		// for-each loop
		for (String key : set1) {
			if (key.equals(Country)) {
				return;
			} else {
				System.out.println("Key : " + key + "\t\t" + "Value : " + map.get(key));
			}
		}
	}
	public void listCountryAfter(String Country)
	{
		Set<String> reverseKeys = map.descendingKeySet();
		Iterator<String> itr1 = reverseKeys.iterator();
		for (String key : reverseKeys) {
			if (key.equals(Country)) {
				return;
			} else {
				System.out.println("Key : " + key + "\t\t" + "Value : " + map.get(key));
			}
		}
	}

}
