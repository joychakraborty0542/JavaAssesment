package com.java.library;

 

import java.util.Scanner;

 

import com.java.author.Author;
import com.java.book.Book;

 

public class Library {

    public static void runApp() {    

        Author joy = new Author("Mark", 36, "male");
        Author ram = new Author("Mona", 32, "male");
        Author shyam = new Author("James", 38, "male");
        Book [] book = new Book[5];

      
        book[0] = new Book("1", "Spring", 1200, 3000, 3, joy);
       book[1] = new Book("2", "java", 1388, 1250000, 3, ram);
       book[2] = new Book("3", "Angular", 388, 50000, 3, shyam);

        System.out.println("Select Book ID from 0 - 3");
        Scanner sc = new Scanner(System.in);
        int index = 0;
        do {
            index = Integer.parseInt(sc.nextLine());
            System.out.println(book[index]);
        } while(index<=book.length); 
    }    

 

    public static void main(String[] args) {
        runApp();
    }

 

}