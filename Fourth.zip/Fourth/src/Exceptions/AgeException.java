package Exceptions;

public class AgeException extends Exception {
	
	public AgeException(String str) {
		  System.out.println(str);
		}

}
