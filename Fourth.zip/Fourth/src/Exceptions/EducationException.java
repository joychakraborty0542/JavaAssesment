package Exceptions;

public class EducationException {
	
	
	public EducationException(String str) {
		  System.out.println(str);
		}

}
