package Exceptions;

public class Candidate {
	private int age;
	private String Education;
	public Candidate(int age, String education) {
		// TODO Auto-generated constructor stub
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		validations();
		this.age = age;
	}
	private void validations() {
		// TODO Auto-generated method stub
		
		
	}
	public String getEducation() {
		return Education;
	}
	public void setEducation(String education) {
		Education = education;
	}
	
	public  void validateAge()
	{
		try {
			if(age<21||age>60)
			{
				throw new AgeException("");
			}
		} catch (AgeException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	public  void validateEducation()
	{
		try {
			if(Education.equalsIgnoreCase("btech"))
			{
				throw new AgeException("");
			}
		} catch (AgeException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}
	

}
