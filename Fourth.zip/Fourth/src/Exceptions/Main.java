package Exceptions;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		
			  Scanner s = new Scanner(System.in);
			  System.out.print("Enter ur age :: ");
			  int age = s.nextInt();
			System.out.print("Enter ur education :: ");

			  Scanner s2 = new Scanner(System.in);
			  String Education=s2.next();
			 
			  
			Candidate candiate=new Candidate(age,Education);
			candiate.validateAge();
			candiate.validateEducation();

			
	}

}
