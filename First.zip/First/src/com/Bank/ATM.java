package com.Bank;

 

public class ATM {
    public static void main(String[] args) {
        Account account = new Account(8000528, "Joy Chakraborty", 1000.d);
        System.out.println("Balance Details as follows..");
        account.display();
        account.deposit(300.0d);
        account.display();
        account.withdraw(2100.0d);
        account.display();

    }
}